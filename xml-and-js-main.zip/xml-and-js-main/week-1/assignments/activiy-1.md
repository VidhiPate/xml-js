# Activity 1

```xml
<?xml version="1.0" encoding="utf-8"?>​
<myMessage>​
  <subject> This is a welcome message </subject>​
  <date> Jan 31, 2018 </date>​
</myMessage>
```

1. Create a simple XML file which describes you and your interests/hobbies

2. How to structure the data in previous activity in order to have Name/Hobbies for a group of 10 people?
