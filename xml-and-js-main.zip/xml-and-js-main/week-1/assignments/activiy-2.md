# Activity 2

Try to display/represent the following Data in XML format

| Empno | Empname | Salary |
| ----- | ------- | ------ |
| 1001  | Alex    | 3000   |
| 1002  | Sarah   | 4000   |
| 1003  | Peter   | 3500   |
