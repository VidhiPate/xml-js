# Evaluation 1

![image info](../assets/1.png)

1. Design HTML page with a button 'Click Me'

2. Develop a JavaScript program which displays “Your name” when user clicks on the button​. Display the message below the button​
