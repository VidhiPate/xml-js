# Activity 1

Design xml file for the following business card and save it to `week-2/assignments/activiy-1.xml`

---

## Joe Marini

- +1 (415) 555-1234 (home)
- +1 (800) 555-9867 (work)
- +1 (510) 555-1212 (mobile)
- joe@joe.com

---
