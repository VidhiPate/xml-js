# Activity 5

Develop a DTD for the `week-2/products.xml` and save to `week-2/assignments/activiy-6.xml`

Using [xmlvalidation.com](xmlvalidation.com) validate you xml file aganst DTD you designed. Save screenshot of sucessfull validation screenshot as `week-2/assignments/activiy-6.png`
