# Activity 2

Update `week-2/assignments/activiy-1.xml` to be able to store multiple business cards and save to `week-2/assignments/activiy-2.xml`

_Tip_: try to use attributes
