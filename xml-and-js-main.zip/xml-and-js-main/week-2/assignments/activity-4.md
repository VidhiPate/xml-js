# Activity 4

Open `week-2/products.xml`

And add following element to each product

```xml
<message>
  For further information, please visit <our website> or call us on #905-111-2222 & +1-800-111- 2222
</message>
```

Save to `week-2/assignments/activiy-4.xml`

_Tip_: Use character data
