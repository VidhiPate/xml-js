# Activity 3

Open `week-2/products.xml`

There are three prices for each product. Modify the XML file and add currency attribute to each price as follow:

- USD
- CAD
- EURO

Modify the XML file

- Add currency symbol to the price data
- Add Trademark symbol to the manufacturer data

Save to `week-2/assignments/activiy-3.xml`
